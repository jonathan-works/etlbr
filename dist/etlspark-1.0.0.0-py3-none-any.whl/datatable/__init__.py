from .columns import TableColumnBronze, TableColumnSilver
from .tables import DataTableBronze, DataTableSilver
